import { useNavigate } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Plane, Monitor, Smartphone, Check, Calendar, ArrowRight,
  Users, Route, CalendarDays, GraduationCap
} from 'lucide-react';
import gsap from 'gsap';

const simulators = [
  { id: 'msfs2020', name: 'MSFS 2020', subtitle: 'Microsoft Flight Simulator', icon: Monitor },
  { id: 'msfs2024', name: 'MSFS 2024', subtitle: 'Microsoft Flight Simulator', icon: Monitor },
  { id: 'xp12', name: 'X-Plane 12', subtitle: 'Laminar Research', icon: Monitor },
  { id: 'xp11', name: 'X-Plane 11', subtitle: 'Laminar Research', icon: Monitor },
  { id: 'infinite', name: 'Infinite Flight', subtitle: 'Mobile Flight Sim', icon: Smartphone },
  { id: 'other', name: 'Other Simulator', subtitle: 'Your choice', icon: Monitor },
];

const aircraftCategories = [
  'Commercial Airliners',
  'General Aviation',
  'Business Jets',
  'Helicopters',
  'Military',
  'Bush/STOL',
  'Gliders',
];

const upcomingEvents = [
  {
    day: '15',
    month: 'MAR',
    title: 'Cross-Country Group Flight',
    description: 'KSEA to KSFO — Join fellow pilots for a scenic west coast journey.',
  },
  {
    day: '18',
    month: 'MAR',
    title: 'Airbus A320 Tutorial Session',
    description: 'Learn the Airbus A320 systems with our certified flight instructors.',
  },
  {
    day: '22',
    month: 'MAR',
    title: 'Sunday Casual Fly-In',
    description: 'Relaxed group flight — all aircraft and skill levels welcome.',
  },
];

export default function FlightLine() {
  const navigate = useNavigate();
  const { state, setSelectedGame, toggleAircraft } = useApp();
  const [selectedSim, setSelectedSim] = useState<string | null>(state.selectedGame);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.fl-section', {
        opacity: 0,
        y: 30,
        duration: 0.6,
        stagger: 0.1,
        ease: 'power3.out',
      });
    }, contentRef);
    return () => ctx.revert();
  }, []);

  const handleSimSelect = (simId: string) => {
    setSelectedSim(simId);
    setSelectedGame(simId);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-16">
      {/* Header Banner */}
      <div className="relative h-[200px] w-full overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/images/flightline-banner.jpg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent" />

        <div className="relative z-10 max-w-[1200px] mx-auto px-6 h-full flex items-end pb-6">
          <div className="flex items-end gap-4">
            <div className="w-20 h-20 rounded-full border-[3px] border-white bg-[#1a1a1a] flex items-center justify-center shadow-lg -mb-10">
              <Plane className="w-8 h-8 text-[#ff6b1a]" />
            </div>
            <div className="mb-2 ml-2">
              <h1 className="text-[36px] font-bold text-white">The FlightLine</h1>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-[#a0a0a0]">2,400+ members</span>
                <span className="flex items-center gap-1.5 text-[#4ade80]">
                  <span className="w-2 h-2 rounded-full bg-[#4ade80]" />
                  342 online
                </span>
              </div>
            </div>
          </div>

          <div className="ml-auto flex gap-3 mb-4">
            <button className="btn-primary py-2 px-5 text-xs h-10">Join Server</button>
            <button className="btn-bordered py-2 px-5 text-xs h-10">View Schedule</button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div ref={contentRef} className="max-w-[1200px] mx-auto px-6 py-12 space-y-12">
        {/* Welcome */}
        <div className="fl-section pt-6">
          <p className="caption mb-2">WELCOME TO THE FLIGHTLINE</p>
          <h2 className="text-[28px] font-bold text-white mb-3">Your Aviation Community</h2>
          <p className="text-[15px] text-[#a0a0a0] leading-relaxed max-w-[600px]">
            Connect with pilots from around the world. Share routes, join group flights, and improve your skills with our community of aviation enthusiasts.
          </p>
        </div>

        {/* Game Selection */}
        <div className="fl-section">
          <p className="caption mb-2">STEP 1</p>
          <h2 className="section-title mb-2">Select Your Simulator</h2>
          <p className="text-[15px] text-[#a0a0a0] mb-6">Choose your primary flight simulation platform</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {simulators.map((sim) => {
              const isSelected = selectedSim === sim.id;
              return (
                <button
                  key={sim.id}
                  onClick={() => handleSimSelect(sim.id)}
                  className={`relative text-left p-5 rounded-xl border transition-all duration-300 hover:scale-[1.02] ${
                    isSelected
                      ? 'border-[#ff6b1a] bg-[rgba(255,107,26,0.05)]'
                      : 'border-[#2a2a2a] bg-[#1a1a1a] hover:border-[#4a4a4a]'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#ff6b1a] flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  )}
                  <sim.icon className={`w-10 h-10 mb-3 ${isSelected ? 'text-[#ff6b1a]' : 'text-[#a0a0a0]'}`} />
                  <h3 className="text-base font-semibold text-white">{sim.name}</h3>
                  <p className="text-xs text-[#a0a0a0] mt-1">{sim.subtitle}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Aircraft Type Selector */}
        <div className="fl-section">
          <p className="caption mb-2">STEP 2</p>
          <h2 className="section-title mb-2">Aircraft Type</h2>
          <p className="text-[15px] text-[#a0a0a0] mb-6">What do you primarily fly? (Select all that apply)</p>

          <div className="flex flex-wrap gap-3">
            {aircraftCategories.map((cat) => {
              const isSelected = state.selectedAircraft.includes(cat);
              return (
                <button
                  key={cat}
                  onClick={() => toggleAircraft(cat)}
                  className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                    isSelected
                      ? 'bg-[#ff6b1a] text-white'
                      : 'bg-[#2a2a2a] text-[#a0a0a0] hover:bg-[#3a3a3a]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Summary */}
        {(selectedSim || state.selectedAircraft.length > 0) && (
          <div className="fl-section bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="text-lg font-semibold text-white mb-4">Your Selection</h3>
            <div className="flex flex-wrap gap-4">
              {selectedSim && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#a0a0a0] uppercase tracking-wider">Simulator:</span>
                  <span className="text-sm text-[#ff6b1a] font-medium">
                    {simulators.find(s => s.id === selectedSim)?.name}
                  </span>
                </div>
              )}
              {state.selectedAircraft.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#a0a0a0] uppercase tracking-wider">Aircraft:</span>
                  <span className="text-sm text-[#ff6b1a] font-medium">
                    {state.selectedAircraft.join(', ')}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Upcoming Events */}
        <div className="fl-section">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="caption mb-2">COMMUNITY</p>
              <h2 className="section-title">Upcoming Events</h2>
            </div>
            <button className="text-sm text-[#ff6b1a] hover:text-white transition-colors flex items-center gap-1">
              View All <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3">
            {upcomingEvents.map((event, i) => (
              <div
                key={i}
                className="flex items-center gap-5 p-5 bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] hover:border-[#4a4a4a] transition-colors"
              >
                <div className="text-center min-w-[60px]">
                  <span className="block text-[28px] font-bold font-mono text-white leading-none">{event.day}</span>
                  <span className="block text-[11px] uppercase tracking-wider text-[#a0a0a0] mt-1">{event.month}</span>
                </div>
                <div className="flex-1 border-l border-[#2a2a2a] pl-5">
                  <h3 className="text-lg font-semibold text-white mb-1">{event.title}</h3>
                  <p className="text-sm text-[#a0a0a0]">{event.description}</p>
                </div>
                <button className="text-sm text-[#ff6b1a] hover:text-white transition-colors flex items-center gap-1">
                  Details <Calendar className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Community Stats */}
        <div className="fl-section">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">
            {[
              { value: '2,400+', label: 'Pilots', icon: Users },
              { value: '120+', label: 'Shared Routes', icon: Route },
              { value: '48', label: 'Weekly Events', icon: CalendarDays },
              { value: '15', label: 'Certified Instructors', icon: GraduationCap },
            ].map((stat, i) => (
              <div
                key={i}
                className={`flex flex-col items-center justify-center py-8 px-4 ${
                  i < 3 ? 'border-r border-[#2a2a2a]' : ''
                }`}
              >
                <stat.icon className="w-5 h-5 text-[#ff6b1a] mb-2" />
                <span className="stat-number">{stat.value}</span>
                <span className="stat-label mt-1">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Access to Tower8 */}
        <div className="fl-section bg-[#1a1a1a] rounded-xl p-8 border border-[#2a2a2a] flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-xl font-semibold text-white mb-2">Looking for ATC Training?</h3>
            <p className="text-[15px] text-[#a0a0a0]">
              Head over to Tower8 for Roblox flight simulator ATC training and certification.
            </p>
          </div>
          <button
            onClick={() => navigate('/tower8')}
            className="btn-orange whitespace-nowrap flex items-center gap-2"
          >
            Go to Tower8
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1a1a1a] py-12 px-6 mt-12">
        <div className="max-w-[1200px] mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <Plane className="w-5 h-5 text-[#ff6b1a]" />
            <span className="text-white font-semibold tracking-[0.08em]">FLIGHT PLATFORM</span>
          </div>
          <div className="flex gap-6">
            <button onClick={() => navigate('/')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">Home</button>
            <button onClick={() => navigate('/flightline')} className="text-sm text-[#ff6b1a]">The FlightLine</button>
            <button onClick={() => navigate('/tower8')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">Tower8</button>
          </div>
          <p className="text-sm text-[#4a4a4a]">&copy; 2025 Flight Platform</p>
        </div>
      </footer>
    </div>
  );
}
