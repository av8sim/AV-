import { useNavigate } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import { useApp } from '@/context/AppContext';
import type { TimeSlot, Instructor } from '@/context/AppContext';
import {
  TowerControl, Gamepad2, Plane, Calendar, Star,
  ArrowRight, Check, ChevronDown, Shield, Trash2, Edit3,
  Clock, BookOpen, GraduationCap, BarChart3
} from 'lucide-react';
import gsap from 'gsap';

const sessionTypeColors: Record<string, string> = {
  tower: 'bg-[#ff6b1a]',
  approach: 'bg-[#3b82f6]',
  ground: 'bg-[#4ade80]',
  center: 'bg-[#a855f7]',
};

const sessionTypeLabels: Record<string, string> = {
  tower: 'Tower Training',
  approach: 'Approach Training',
  ground: 'Ground Training',
  center: 'Center/Enroute',
};

const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const weekDates = ['May 19', 'May 20', 'May 21', 'May 22', 'May 23', 'May 24', 'May 25'];

export default function Tower8() {
  const navigate = useNavigate();
  const { state, bookSlot, cancelBooking, addInstructor, removeInstructor, toggleInstructorStatus } = useApp();
  const contentRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState<'book' | 'instructor'>('book');
  const [selectedDay, setSelectedDay] = useState(0);
  const [selectedGame, setSelectedGame] = useState<'PTFS' | 'Project Flight' | null>(null);
  const [showAddInstructor, setShowAddInstructor] = useState(false);
  const [newInstructorName, setNewInstructorName] = useState('');
  const [newInstructorRole, setNewInstructorRole] = useState('Tower Instructor');
  const [newInstructorGames, setNewInstructorGames] = useState<string[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.t8-section', {
        opacity: 0,
        y: 30,
        duration: 0.6,
        stagger: 0.1,
        ease: 'power3.out',
      });
    }, contentRef);
    return () => ctx.revert();
  }, []);

  const filteredSlots = state.timeSlots.filter(
    (slot: TimeSlot) => slot.day === weekDays[selectedDay] &&
    (!selectedGame || slot.game === selectedGame)
  );

  const myBookings = state.timeSlots.filter((slot: TimeSlot) => slot.trainee === 'You');
  const instructorBookings = state.timeSlots.filter(
    (slot: TimeSlot) => slot.status === 'booked' || slot.status === 'pending'
  );

  const handleAddInstructor = () => {
    if (!newInstructorName.trim()) return;
    const instructor: Instructor = {
      id: Date.now().toString(),
      name: newInstructorName,
      role: newInstructorRole,
      games: newInstructorGames.length > 0 ? newInstructorGames : ['PTFS'],
      sessions: 0,
      hours: 0,
      rating: 5.0,
      status: 'active',
    };
    addInstructor(instructor);
    setNewInstructorName('');
    setNewInstructorGames([]);
    setShowAddInstructor(false);
  };

  const toggleGame = (game: string) => {
    setNewInstructorGames(prev =>
      prev.includes(game) ? prev.filter(g => g !== game) : [...prev, game]
    );
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] pt-16">
      {/* Header Banner */}
      <div className="relative h-[200px] w-full overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/images/tower8-banner.jpg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent" />

        <div className="relative z-10 max-w-[1200px] mx-auto px-6 h-full flex items-end pb-6">
          <div className="flex items-end gap-4">
            <div className="w-20 h-20 rounded-full border-[3px] border-white bg-[#1a1a1a] flex items-center justify-center shadow-lg -mb-10">
              <TowerControl className="w-8 h-8 text-[#ff6b1a]" />
            </div>
            <div className="mb-2 ml-2">
              <h1 className="text-[36px] font-bold text-white">Tower8</h1>
              <div className="flex items-center gap-3 text-sm">
                <span className="text-[#a0a0a0]">ATC Training & Roblox Flight Simulation</span>
                <span className="flex items-center gap-1.5 text-[#4ade80]">
                  <span className="w-2 h-2 rounded-full bg-[#4ade80]" />
                  156 online
                </span>
              </div>
            </div>
          </div>

          <div className="ml-auto flex gap-3 mb-4">
            <button className="btn-primary py-2 px-5 text-xs h-10">Join Server</button>
            <button
              onClick={() => setActiveTab('book')}
              className="btn-orange py-2 px-5 text-xs h-10"
            >
              Book Training
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div ref={contentRef} className="max-w-[1200px] mx-auto px-6 py-12 space-y-12">
        {/* Welcome */}
        <div className="t8-section pt-6">
          <p className="caption mb-2">WELCOME TO TOWER8</p>
          <h2 className="text-[28px] font-bold text-white mb-3">ATC Training Portal</h2>
          <p className="text-[15px] text-[#a0a0a0] leading-relaxed max-w-[600px]">
            Master air traffic control procedures on Roblox flight simulators. Learn from certified instructors and earn your controller ratings.
          </p>
        </div>

        {/* How Training Works */}
        <div className="t8-section">
          <p className="caption mb-2">PROCESS</p>
          <h2 className="section-title mb-8">How Training Works</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
            {/* Connecting line */}
            <div className="hidden md:block absolute top-[60px] left-[20%] right-[20%] h-px bg-[#2a2a2a]" />

            {[
              {
                icon: Gamepad2,
                title: 'Select Your Game',
                description: 'Choose between Pilot Training Flight Simulator or Project Flight on Roblox.',
              },
              {
                icon: Plane,
                title: 'Choose Aircraft Type',
                description: 'Select the aircraft category you want training for.',
              },
              {
                icon: Calendar,
                title: 'Book Your Session',
                description: 'Pick a time slot that works for you. Our certified instructors will guide you.',
              },
            ].map((step, i) => (
              <div key={i} className="card-dark p-6 relative z-10">
                <div className="w-10 h-10 rounded-full bg-[#ff6b1a]/10 flex items-center justify-center mb-4">
                  <step.icon className="w-5 h-5 text-[#ff6b1a]" />
                </div>
                <div className="text-[11px] uppercase tracking-wider text-[#ff6b1a] mb-2">Step {i + 1}</div>
                <h3 className="text-lg font-semibold text-white mb-2">{step.title}</h3>
                <p className="text-sm text-[#a0a0a0] leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Roblox Game Selector */}
        <div className="t8-section">
          <p className="caption mb-2">PLATFORM</p>
          <h2 className="section-title mb-6">Select Your Platform</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* PTFS Card */}
            <button
              onClick={() => setSelectedGame(selectedGame === 'PTFS' ? null : 'PTFS')}
              className={`relative overflow-hidden rounded-xl text-left transition-all duration-300 hover:scale-[1.02] ${
                selectedGame === 'PTFS' ? 'ring-2 ring-[#ff6b1a]' : ''
              }`}
              style={{ height: '280px' }}
            >
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: 'url(/images/ptfs-card.jpg)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" />
              <div className="relative z-10 h-full flex flex-col justify-end p-6">
                <h3 className="text-xl font-semibold text-white mb-2">Pilot Training Flight Simulator</h3>
                <p className="text-sm text-[#a0a0a0] mb-3">
                  The most popular Roblox flight simulator. Train with realistic ATC procedures.
                </p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {['Beginner Friendly', 'ATC', 'Multiplayer'].map(tag => (
                    <span key={tag} className="px-2 py-0.5 bg-white/10 rounded text-[10px] uppercase tracking-wider text-white/80">
                      {tag}
                    </span>
                  ))}
                </div>
                <span className={`text-sm font-medium ${selectedGame === 'PTFS' ? 'text-[#ff6b1a]' : 'text-white'}`}>
                  {selectedGame === 'PTFS' ? 'Selected' : 'Select PTFS'}
                </span>
              </div>
            </button>

            {/* Project Flight Card */}
            <button
              onClick={() => setSelectedGame(selectedGame === 'Project Flight' ? null : 'Project Flight')}
              className={`relative overflow-hidden rounded-xl text-left transition-all duration-300 hover:scale-[1.02] ${
                selectedGame === 'Project Flight' ? 'ring-2 ring-[#ff6b1a]' : ''
              }`}
              style={{ height: '280px' }}
            >
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: 'url(/images/project-flight-card.jpg)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" />
              <div className="relative z-10 h-full flex flex-col justify-end p-6">
                <h3 className="text-xl font-semibold text-white mb-2">Project Flight</h3>
                <p className="text-sm text-[#a0a0a0] mb-3">
                  Next-gen Roblox aviation with advanced flight physics and detailed aircraft systems.
                </p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {['Advanced', 'Realistic', 'Study Level'].map(tag => (
                    <span key={tag} className="px-2 py-0.5 bg-white/10 rounded text-[10px] uppercase tracking-wider text-white/80">
                      {tag}
                    </span>
                  ))}
                </div>
                <span className={`text-sm font-medium ${selectedGame === 'Project Flight' ? 'text-[#ff6b1a]' : 'text-white'}`}>
                  {selectedGame === 'Project Flight' ? 'Selected' : 'Select Project Flight'}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Training Schedule / Availability System */}
        <div className="t8-section">
          <p className="caption mb-2">SCHEDULING</p>
          <h2 className="section-title mb-6">Training Availability</h2>

          {/* Tab Switcher */}
          <div className="flex bg-[#1a1a1a] rounded-xl p-1 w-fit mb-8">
            <button
              onClick={() => setActiveTab('book')}
              className={`px-6 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'book'
                  ? 'bg-[#ff6b1a] text-white'
                  : 'text-[#a0a0a0] hover:text-white'
              }`}
            >
              Book a Session
            </button>
            <button
              onClick={() => setActiveTab('instructor')}
              className={`px-6 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'instructor'
                  ? 'bg-[#ff6b1a] text-white'
                  : 'text-[#a0a0a0] hover:text-white'
              }`}
            >
              Instructor Dashboard
            </button>
          </div>

          {activeTab === 'book' ? (
            /* Book a Session View */
            <div>
              {/* Week Navigator */}
              <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
                {weekDays.map((day, i) => (
                  <button
                    key={day}
                    onClick={() => setSelectedDay(i)}
                    className={`flex flex-col items-center min-w-[70px] py-3 px-4 rounded-xl border transition-all ${
                      selectedDay === i
                        ? 'border-[#ff6b1a] bg-[rgba(255,107,26,0.05)]'
                        : 'border-[#2a2a2a] bg-[#1a1a1a] hover:border-[#4a4a4a]'
                    }`}
                  >
                    <span className="text-[11px] uppercase tracking-wider text-[#a0a0a0]">{day}</span>
                    <span className={`text-[20px] font-bold font-mono mt-1 ${selectedDay === i ? 'text-[#ff6b1a]' : 'text-white'}`}>
                      {weekDates[i].split(' ')[1]}
                    </span>
                  </button>
                ))}
              </div>

              {/* My Bookings */}
              {myBookings.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#4ade80]" />
                    My Bookings
                  </h3>
                  <div className="space-y-2">
                    {myBookings.map((slot: TimeSlot) => (
                      <div key={slot.id} className="flex items-center gap-4 p-4 bg-[#1a1a1a] rounded-xl border border-[#4ade80]/30">
                        <div className="text-center min-w-[80px]">
                          <span className="block text-lg font-bold font-mono text-white">{slot.time}</span>
                          <span className="text-[11px] uppercase text-[#a0a0a0]">{slot.day} {slot.date}</span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`px-2 py-0.5 rounded text-[10px] uppercase text-white ${sessionTypeColors[slot.sessionType]}`}>
                              {sessionTypeLabels[slot.sessionType]}
                            </span>
                            <span className="text-xs text-[#a0a0a0]">{slot.game}</span>
                          </div>
                          <span className="text-sm text-white">Instructor: {slot.instructor}</span>
                        </div>
                        <button
                          onClick={() => cancelBooking(slot.id)}
                          className="px-3 py-1.5 rounded-lg border border-red-500/50 text-red-400 text-xs hover:bg-red-500/10 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Time Slots Grid */}
              <h3 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#ff6b1a]" />
                Available Slots — {weekDays[selectedDay]} {weekDates[selectedDay]}
              </h3>

              {filteredSlots.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredSlots.map((slot: TimeSlot) => (
                    <div
                      key={slot.id}
                      className={`p-4 rounded-xl border transition-all ${
                        slot.status === 'booked'
                          ? 'bg-[#1a1a1a]/50 border-[#2a2a2a] opacity-60'
                          : 'bg-[#1a1a1a] border-[#2a2a2a] hover:border-[#4a4a4a]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-lg font-bold font-mono text-white">{slot.time}</span>
                        {slot.status === 'booked' ? (
                          <span className="px-2 py-0.5 bg-[#4a4a4a] rounded text-[10px] uppercase text-[#a0a0a0]">
                            Booked
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-[#4ade80]/10 rounded text-[10px] uppercase text-[#4ade80]">
                            Available
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mb-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase text-white ${sessionTypeColors[slot.sessionType]}`}>
                          {sessionTypeLabels[slot.sessionType]}
                        </span>
                        <span className="text-xs text-[#a0a0a0]">{slot.game}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-[#a0a0a0]">Instructor: {slot.instructor}</span>
                        {slot.status === 'available' ? (
                          <button
                            onClick={() => bookSlot(slot.id)}
                            className="px-4 py-1.5 rounded-lg border border-[#ff6b1a] text-[#ff6b1a] text-xs hover:bg-[#ff6b1a] hover:text-white transition-all"
                          >
                            Book
                          </button>
                        ) : (
                          <span className="text-xs text-[#4a4a4a]">{slot.trainee}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-[#1a1a1a] rounded-xl border border-[#2a2a2a]">
                  <Calendar className="w-8 h-8 text-[#4a4a4a] mx-auto mb-3" />
                  <p className="text-[#a0a0a0]">No available slots for this day</p>
                </div>
              )}
            </div>
          ) : (
            /* Instructor Dashboard View */
            <div className="space-y-8">
              {/* Instructor Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { value: '12', label: 'Sessions This Month', icon: BookOpen },
                  { value: '48', label: 'Total Hours', icon: Clock },
                  { value: '4.9', label: 'Rating', icon: Star },
                  { value: '156', label: 'Students Trained', icon: GraduationCap },
                ].map((stat, i) => (
                  <div key={i} className="card-dark p-5 flex flex-col items-center text-center">
                    <stat.icon className="w-5 h-5 text-[#ff6b1a] mb-2" />
                    <span className="stat-number text-[24px]">{stat.value}</span>
                    <span className="stat-label mt-1">{stat.label}</span>
                  </div>
                ))}
              </div>

              {/* My Bookings Table */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-[#ff6b1a]" />
                  My Bookings
                </h3>
                <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-[#2a2a2a]">
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Date</th>
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Time</th>
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Trainee</th>
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Game</th>
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Type</th>
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Status</th>
                          <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {instructorBookings.map((slot: TimeSlot, i: number) => (
                          <tr
                            key={slot.id}
                            className={`border-b border-[#2a2a2a] ${i % 2 === 0 ? 'bg-[#1a1a1a]' : 'bg-[#0a0a0a]'}`}
                          >
                            <td className="px-4 py-3 text-white">{slot.day} {slot.date}</td>
                            <td className="px-4 py-3 text-white font-mono">{slot.time}</td>
                            <td className="px-4 py-3 text-white">{slot.trainee}</td>
                            <td className="px-4 py-3 text-[#a0a0a0]">{slot.game}</td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] uppercase text-white ${sessionTypeColors[slot.sessionType]}`}>
                                {sessionTypeLabels[slot.sessionType]}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] uppercase ${
                                slot.status === 'booked'
                                  ? 'bg-[#4ade80]/10 text-[#4ade80]'
                                  : slot.status === 'pending'
                                  ? 'bg-[#ff6b1a]/10 text-[#ff6b1a]'
                                  : 'bg-[#4a4a4a]/30 text-[#a0a0a0]'
                              }`}>
                                {slot.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex gap-2">
                                <button className="text-[#ff6b1a] hover:text-white transition-colors text-xs">
                                  Join
                                </button>
                                <button className="text-red-400 hover:text-red-300 transition-colors text-xs">
                                  Cancel
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Instructor Role Management — Admin Only */}
        {state.userRole === 'admin' && (
          <div className="t8-section">
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="caption mb-2">ADMIN</p>
                <h2 className="section-title flex items-center gap-2">
                  <Shield className="w-6 h-6 text-[#ff6b1a]" />
                  Instructor Management
                </h2>
              </div>
              <button
                onClick={() => setShowAddInstructor(!showAddInstructor)}
                className="btn-orange text-xs py-2 px-4"
              >
                {showAddInstructor ? 'Cancel' : 'Add Instructor'}
              </button>
            </div>

            {/* Add Instructor Form */}
            {showAddInstructor && (
              <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a] mb-6">
                <h3 className="text-lg font-semibold text-white mb-4">Add New Instructor</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="caption block mb-2">Discord Username</label>
                    <input
                      type="text"
                      value={newInstructorName}
                      onChange={(e) => setNewInstructorName(e.target.value)}
                      placeholder="e.g. ATC_Master"
                      className="w-full h-11 px-4 bg-[#0a0a0a] border border-[#2a2a2a] rounded-lg text-white text-sm focus:border-[#ff6b1a] focus:outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="caption block mb-2">Role</label>
                    <div className="relative">
                      <select
                        value={newInstructorRole}
                        onChange={(e) => setNewInstructorRole(e.target.value)}
                        className="w-full h-11 px-4 pr-10 bg-[#0a0a0a] border border-[#2a2a2a] rounded-lg text-white text-sm appearance-none focus:border-[#ff6b1a] focus:outline-none transition-colors"
                      >
                        <option>Tower Instructor</option>
                        <option>Approach Instructor</option>
                        <option>Ground Instructor</option>
                        <option>Center Instructor</option>
                        <option>Admin</option>
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#a0a0a0] pointer-events-none" />
                    </div>
                  </div>
                </div>
                <div className="mb-4">
                  <label className="caption block mb-2">Games They Can Teach</label>
                  <div className="flex gap-3">
                    {['PTFS', 'Project Flight'].map(game => (
                      <button
                        key={game}
                        onClick={() => toggleGame(game)}
                        className={`px-4 py-2 rounded-lg text-sm border transition-all ${
                          newInstructorGames.includes(game)
                            ? 'border-[#ff6b1a] bg-[rgba(255,107,26,0.1)] text-[#ff6b1a]'
                            : 'border-[#2a2a2a] text-[#a0a0a0] hover:border-[#4a4a4a]'
                        }`}
                      >
                        {newInstructorGames.includes(game) && <Check className="w-3 h-3 inline mr-1" />}
                        {game}
                      </button>
                    ))}
                  </div>
                </div>
                <button
                  onClick={handleAddInstructor}
                  className="btn-orange text-xs py-2 px-6"
                >
                  Add Instructor
                </button>
              </div>
            )}

            {/* Instructor List */}
            <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#2a2a2a]">
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Name</th>
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Role</th>
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Games</th>
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Sessions</th>
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Rating</th>
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Status</th>
                      <th className="text-left px-4 py-3 text-[#a0a0a0] font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.instructors.map((instructor: Instructor, i: number) => (
                      <tr
                        key={instructor.id}
                        className={`border-b border-[#2a2a2a] ${i % 2 === 0 ? 'bg-[#1a1a1a]' : 'bg-[#0a0a0a]'}`}
                      >
                        <td className="px-4 py-3 text-white font-medium">{instructor.name}</td>
                        <td className="px-4 py-3 text-[#a0a0a0]">{instructor.role}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1">
                            {instructor.games.map(g => (
                              <span key={g} className="px-1.5 py-0.5 bg-[#2a2a2a] rounded text-[10px] text-[#a0a0a0]">
                                {g}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-white font-mono">{instructor.sessions}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-[#ff6b1a] fill-[#ff6b1a]" />
                            <span className="text-white">{instructor.rating}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => toggleInstructorStatus(instructor.id)}
                            className={`px-2 py-0.5 rounded text-[10px] uppercase transition-colors ${
                              instructor.status === 'active'
                                ? 'bg-[#4ade80]/10 text-[#4ade80] hover:bg-[#4ade80]/20'
                                : 'bg-[#4a4a4a]/30 text-[#a0a0a0] hover:bg-[#4a4a4a]/50'
                            }`}
                          >
                            {instructor.status}
                          </button>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2">
                            <button className="text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => removeInstructor(instructor.id)}
                              className="text-[#a0a0a0] hover:text-red-400 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Stats Overview */}
        <div className="t8-section">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">
            {[
              { value: '800+', label: 'Controllers', icon: TowerControl },
              { value: '50+', label: 'Trainers', icon: GraduationCap },
              { value: '200+', label: 'Sessions/Month', icon: BarChart3 },
              { value: '95%', label: 'Pass Rate', icon: Check },
            ].map((stat, i) => (
              <div
                key={i}
                className={`flex flex-col items-center justify-center py-8 px-4 ${
                  i < 3 ? 'border-r border-[#2a2a2a]' : ''
                }`}
              >
                <stat.icon className="w-5 h-5 text-[#ff6b1a] mb-2" />
                <span className="stat-number text-[24px]">{stat.value}</span>
                <span className="stat-label mt-1">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Access to FlightLine */}
        <div className="t8-section bg-[#1a1a1a] rounded-xl p-8 border border-[#2a2a2a] flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-xl font-semibold text-white mb-2">General Aviation Community?</h3>
            <p className="text-[15px] text-[#a0a0a0]">
              Join The FlightLine for MSFS, X-Plane, and Infinite Flight community events.
            </p>
          </div>
          <button
            onClick={() => navigate('/flightline')}
            className="btn-orange whitespace-nowrap flex items-center gap-2"
          >
            Go to The FlightLine
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1a1a1a] py-12 px-6 mt-12">
        <div className="max-w-[1200px] mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <Plane className="w-5 h-5 text-[#ff6b1a]" />
            <span className="text-white font-semibold tracking-[0.08em]">FLIGHT PLATFORM</span>
          </div>
          <div className="flex gap-6">
            <button onClick={() => navigate('/')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">Home</button>
            <button onClick={() => navigate('/flightline')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">The FlightLine</button>
            <button onClick={() => navigate('/tower8')} className="text-sm text-[#ff6b1a]">Tower8</button>
          </div>
          <p className="text-sm text-[#4a4a4a]">&copy; 2025 Flight Platform</p>
        </div>
      </footer>
    </div>
  );
}
