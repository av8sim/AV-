import { useNavigate } from 'react-router-dom';
import { useEffect, useRef } from 'react';
import InstrumentPanel from '@/components/InstrumentPanel';
import { Plane, TowerControl, Users, Route, Radio, GraduationCap } from 'lucide-react';
import gsap from 'gsap';

export default function ServerHub() {
  const navigate = useNavigate();
  const heroRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Entrance animations
    const ctx = gsap.context(() => {
      gsap.from('.hero-caption', { opacity: 0, y: 20, duration: 0.8, delay: 0.3, ease: 'power3.out' });
      gsap.from('.hero-title', { opacity: 0, y: 30, duration: 0.8, delay: 0.5, ease: 'power3.out' });
      gsap.from('.hero-body', { opacity: 0, y: 30, duration: 0.8, delay: 0.7, ease: 'power3.out' });
      gsap.from('.hero-buttons', { opacity: 0, y: 30, duration: 0.8, delay: 0.9, ease: 'power3.out' });

      if (cardsRef.current) {
        gsap.from('.server-card', {
          opacity: 0,
          y: 40,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
          },
        });
      }
    });

    return () => ctx.revert();
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Hero Section with 3D Instrument */}
      <div ref={heroRef} className="relative h-screen w-full overflow-hidden">
        {/* 3D Instrument Background */}
        <InstrumentPanel />

        {/* Left gradient overlay for text readability */}
        <div
          className="absolute inset-0 z-[1] pointer-events-none"
          style={{
            background: 'linear-gradient(to right, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 35%, transparent 60%)',
          }}
        />

        {/* Hero Content */}
        <div className="relative z-[2] h-full flex items-center">
          <div className="max-w-[1200px] mx-auto w-full px-6">
            <div className="max-w-[480px]">
              <p className="hero-caption caption mb-4">AVIATION TRAINING PLATFORM</p>
              <h1 className="hero-title text-[56px] md:text-[64px] font-extrabold text-white leading-[1.0] tracking-[-0.02em] mb-6">
                Choose Your<br />Flight Path
              </h1>
              <p className="hero-body text-[15px] text-[#a0a0a0] leading-[1.7] tracking-[0.01em] mb-8 max-w-[380px]">
                Join The FlightLine for general aviation simulation, or Tower8 for ATC training on Roblox. Your journey starts here.
              </p>
              <div className="hero-buttons flex gap-4 flex-wrap">
                <button
                  onClick={() => navigate('/flightline')}
                  className="btn-primary h-12 w-[180px] flex items-center justify-center gap-2"
                >
                  <Plane className="w-4 h-4" />
                  The FlightLine
                </button>
                <button
                  onClick={() => navigate('/tower8')}
                  className="btn-bordered h-12 w-[180px] flex items-center justify-center gap-2"
                >
                  <TowerControl className="w-4 h-4" />
                  Tower8
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Server Cards Section */}
      <div ref={cardsRef} className="py-20 px-6 bg-[#0a0a0a]">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-12">
            <p className="caption mb-3">SELECT A SERVER</p>
            <h2 className="text-[36px] md:text-[48px] font-bold text-white leading-[1.1] tracking-[-0.01em]">
              Two Communities.<br />One Passion.
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* The FlightLine Card */}
            <div
              className="server-card group relative overflow-hidden rounded-xl cursor-pointer"
              style={{ height: '400px' }}
              onClick={() => navigate('/flightline')}
            >
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105"
                style={{ backgroundImage: 'url(/images/flightline-server.jpg)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent" />

              <div className="relative z-10 h-full flex flex-col justify-between p-6 md:p-8">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full border-2 border-white flex items-center justify-center bg-[#1a1a1a]">
                      <Plane className="w-5 h-5 text-[#ff6b1a]" />
                    </div>
                    <div>
                      <h3 className="text-[28px] font-bold text-white leading-tight">The FlightLine</h3>
                      <p className="text-sm text-[#a0a0a0]">General Aviation Community</p>
                    </div>
                  </div>

                  <p className="text-[15px] text-[#a0a0a0] leading-relaxed max-w-[320px] mb-4">
                    For MSFS 2020/2024, X-Plane, Infinite Flight, and all major flight simulators. Connect with fellow pilots, share routes, and explore the skies together.
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {['MSFS', 'X-Plane 12', 'Infinite Flight'].map(tag => (
                      <span key={tag} className="px-3 py-1 bg-[#2a2a2a] rounded text-[11px] uppercase tracking-wider text-[#a0a0a0]">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex gap-6">
                    <div>
                      <span className="stat-number text-[24px]">2,400+</span>
                      <span className="stat-label block mt-1">Pilots</span>
                    </div>
                    <div>
                      <span className="stat-number text-[24px]">120+</span>
                      <span className="stat-label block mt-1">Routes</span>
                    </div>
                  </div>
                </div>

                <button className="btn-bordered w-fit mt-4 flex items-center gap-2">
                  Join Server
                  <Plane className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Tower8 Card */}
            <div
              className="server-card group relative overflow-hidden rounded-xl cursor-pointer"
              style={{ height: '400px' }}
              onClick={() => navigate('/tower8')}
            >
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105"
                style={{ backgroundImage: 'url(/images/tower8-server.jpg)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent" />

              <div className="relative z-10 h-full flex flex-col justify-between p-6 md:p-8">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full border-2 border-white flex items-center justify-center bg-[#1a1a1a]">
                      <TowerControl className="w-5 h-5 text-[#ff6b1a]" />
                    </div>
                    <div>
                      <h3 className="text-[28px] font-bold text-white leading-tight">Tower8</h3>
                      <p className="text-sm text-[#a0a0a0]">ATC Training & Roblox Flight Sims</p>
                    </div>
                  </div>

                  <p className="text-[15px] text-[#a0a0a0] leading-relaxed max-w-[320px] mb-4">
                    Master air traffic control on Pilot Training Flight Simulator and Project Flight. Learn proper phraseology, ATC procedures, and earn your controller rating.
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {['PTFS', 'Project Flight', 'ATC Training'].map(tag => (
                      <span key={tag} className="px-3 py-1 bg-[#2a2a2a] rounded text-[11px] uppercase tracking-wider text-[#a0a0a0]">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex gap-6">
                    <div>
                      <span className="stat-number text-[24px]">800+</span>
                      <span className="stat-label block mt-1">Controllers</span>
                    </div>
                    <div>
                      <span className="stat-number text-[24px]">50+</span>
                      <span className="stat-label block mt-1">Trainers</span>
                    </div>
                  </div>
                </div>

                <button className="btn-bordered w-fit mt-4 flex items-center gap-2">
                  Join Server
                  <TowerControl className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Overview */}
      <div className="py-20 px-6 bg-[#0a0a0a] border-t border-[#1a1a1a]">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-12">
            <p className="caption mb-3">PLATFORM FEATURES</p>
            <h2 className="text-[36px] font-bold text-white leading-[1.1]">
              Everything You Need
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Users, title: 'Community', desc: 'Connect with thousands of aviation enthusiasts and professionals.' },
              { icon: Route, title: 'Route Sharing', desc: 'Share and discover flight routes across all major simulators.' },
              { icon: Radio, title: 'ATC Training', desc: 'Learn proper ATC phraseology and procedures from certified trainers.' },
              { icon: GraduationCap, title: 'Certifications', desc: 'Earn ratings and certifications as you progress through training.' },
            ].map((feature, i) => (
              <div key={i} className="card-dark p-6">
                <feature.icon className="w-8 h-8 text-[#ff6b1a] mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-sm text-[#a0a0a0] leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#1a1a1a] py-12 px-6">
        <div className="max-w-[1200px] mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <Plane className="w-5 h-5 text-[#ff6b1a]" />
            <span className="text-white font-semibold tracking-[0.08em]">FLIGHT PLATFORM</span>
          </div>
          <div className="flex gap-6">
            <button onClick={() => navigate('/')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">Home</button>
            <button onClick={() => navigate('/flightline')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">The FlightLine</button>
            <button onClick={() => navigate('/tower8')} className="text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors">Tower8</button>
            <span className="text-sm text-[#a0a0a0]">Discord</span>
          </div>
          <p className="text-sm text-[#4a4a4a]">&copy; 2025 Flight Platform</p>
        </div>
      </footer>
    </div>
  );
}
