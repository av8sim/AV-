import { Routes, Route } from 'react-router-dom';
import { AppProvider } from '@/context/AppContext';
import Navbar from '@/components/Navbar';
import ServerHub from '@/pages/ServerHub';
import FlightLine from '@/pages/FlightLine';
import Tower8 from '@/pages/Tower8';

function App() {
  return (
    <AppProvider>
      <Navbar />
      <Routes>
        <Route path="/" element={<ServerHub />} />
        <Route path="/flightline" element={<FlightLine />} />
        <Route path="/tower8" element={<Tower8 />} />
      </Routes>
    </AppProvider>
  );
}

export default App;
