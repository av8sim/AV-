import React, { createContext, useContext, useState, useCallback } from 'react';

export interface TimeSlot {
  id: string;
  day: string;
  date: string;
  time: string;
  instructor: string;
  game: string;
  sessionType: 'tower' | 'approach' | 'ground' | 'center';
  status: 'available' | 'booked' | 'pending';
  trainee?: string;
}

export interface Instructor {
  id: string;
  name: string;
  role: string;
  games: string[];
  sessions: number;
  hours: number;
  rating: number;
  status: 'active' | 'inactive';
}

export interface AppState {
  selectedServer: 'flightline' | 'tower8' | null;
  selectedGame: string | null;
  selectedAircraft: string[];
  userRole: 'trainee' | 'instructor' | 'admin';
  instructors: Instructor[];
  timeSlots: TimeSlot[];
  bookings: TimeSlot[];
}

interface AppContextType {
  state: AppState;
  setSelectedServer: (server: 'flightline' | 'tower8' | null) => void;
  setSelectedGame: (game: string | null) => void;
  toggleAircraft: (aircraft: string) => void;
  setUserRole: (role: 'trainee' | 'instructor' | 'admin') => void;
  addInstructor: (instructor: Instructor) => void;
  removeInstructor: (id: string) => void;
  toggleInstructorStatus: (id: string) => void;
  bookSlot: (slotId: string) => void;
  cancelBooking: (slotId: string) => void;
  addTimeSlots: (slots: TimeSlot[]) => void;
}

const initialState: AppState = {
  selectedServer: null,
  selectedGame: null,
  selectedAircraft: [],
  userRole: 'trainee',
  instructors: [
    { id: '1', name: 'ATC_Master', role: 'Tower Instructor', games: ['PTFS', 'Project Flight'], sessions: 48, hours: 120, rating: 4.9, status: 'active' },
    { id: '2', name: 'SkyGuide', role: 'Approach Instructor', games: ['PTFS'], sessions: 32, hours: 85, rating: 4.8, status: 'active' },
    { id: '3', name: 'TowerPro', role: 'Ground Instructor', games: ['Project Flight'], sessions: 24, hours: 60, rating: 4.7, status: 'active' },
    { id: '4', name: 'RadarOps', role: 'Center Instructor', games: ['PTFS', 'Project Flight'], sessions: 56, hours: 140, rating: 5.0, status: 'active' },
  ],
  timeSlots: [
    { id: '1', day: 'Mon', date: 'May 19', time: '14:00 - 15:00', instructor: 'ATC_Master', game: 'PTFS', sessionType: 'tower', status: 'available' },
    { id: '2', day: 'Mon', date: 'May 19', time: '16:00 - 17:00', instructor: 'SkyGuide', game: 'PTFS', sessionType: 'approach', status: 'available' },
    { id: '3', day: 'Mon', date: 'May 19', time: '18:00 - 19:00', instructor: 'TowerPro', game: 'Project Flight', sessionType: 'ground', status: 'booked', trainee: 'Pilot123' },
    { id: '4', day: 'Tue', date: 'May 20', time: '14:00 - 15:00', instructor: 'RadarOps', game: 'PTFS', sessionType: 'center', status: 'available' },
    { id: '5', day: 'Tue', date: 'May 20', time: '16:00 - 17:00', instructor: 'ATC_Master', game: 'Project Flight', sessionType: 'tower', status: 'available' },
    { id: '6', day: 'Tue', date: 'May 20', time: '19:00 - 20:00', instructor: 'SkyGuide', game: 'PTFS', sessionType: 'approach', status: 'available' },
    { id: '7', day: 'Wed', date: 'May 21', time: '15:00 - 16:00', instructor: 'TowerPro', game: 'PTFS', sessionType: 'ground', status: 'available' },
    { id: '8', day: 'Wed', date: 'May 21', time: '17:00 - 18:00', instructor: 'RadarOps', game: 'Project Flight', sessionType: 'center', status: 'available' },
    { id: '9', day: 'Thu', date: 'May 22', time: '14:00 - 15:00', instructor: 'ATC_Master', game: 'PTFS', sessionType: 'tower', status: 'available' },
    { id: '10', day: 'Thu', date: 'May 22', time: '16:00 - 17:00', instructor: 'SkyGuide', game: 'Project Flight', sessionType: 'approach', status: 'booked', trainee: 'Aviator_X' },
    { id: '11', day: 'Fri', date: 'May 23', time: '15:00 - 16:00', instructor: 'TowerPro', game: 'PTFS', sessionType: 'ground', status: 'available' },
    { id: '12', day: 'Fri', date: 'May 23', time: '18:00 - 19:00', instructor: 'RadarOps', game: 'Project Flight', sessionType: 'center', status: 'available' },
  ],
  bookings: [],
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(initialState);

  const setSelectedServer = useCallback((server: 'flightline' | 'tower8' | null) => {
    setState(prev => ({ ...prev, selectedServer: server }));
  }, []);

  const setSelectedGame = useCallback((game: string | null) => {
    setState(prev => ({ ...prev, selectedGame: game }));
  }, []);

  const toggleAircraft = useCallback((aircraft: string) => {
    setState(prev => ({
      ...prev,
      selectedAircraft: prev.selectedAircraft.includes(aircraft)
        ? prev.selectedAircraft.filter(a => a !== aircraft)
        : [...prev.selectedAircraft, aircraft],
    }));
  }, []);

  const setUserRole = useCallback((role: 'trainee' | 'instructor' | 'admin') => {
    setState(prev => ({ ...prev, userRole: role }));
  }, []);

  const addInstructor = useCallback((instructor: Instructor) => {
    setState(prev => ({
      ...prev,
      instructors: [...prev.instructors, instructor],
    }));
  }, []);

  const removeInstructor = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      instructors: prev.instructors.filter(i => i.id !== id),
    }));
  }, []);

  const toggleInstructorStatus = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      instructors: prev.instructors.map(i =>
        i.id === id ? { ...i, status: i.status === 'active' ? 'inactive' : 'active' } : i
      ),
    }));
  }, []);

  const bookSlot = useCallback((slotId: string) => {
    setState(prev => ({
      ...prev,
      timeSlots: prev.timeSlots.map(s =>
        s.id === slotId ? { ...s, status: 'booked' as const, trainee: 'You' } : s
      ),
      bookings: [...prev.bookings, prev.timeSlots.find(s => s.id === slotId)!].filter(Boolean),
    }));
  }, []);

  const cancelBooking = useCallback((slotId: string) => {
    setState(prev => ({
      ...prev,
      timeSlots: prev.timeSlots.map(s =>
        s.id === slotId ? { ...s, status: 'available' as const, trainee: undefined } : s
      ),
      bookings: prev.bookings.filter(b => b.id !== slotId),
    }));
  }, []);

  const addTimeSlots = useCallback((slots: TimeSlot[]) => {
    setState(prev => ({
      ...prev,
      timeSlots: [...prev.timeSlots, ...slots],
    }));
  }, []);

  return (
    <AppContext.Provider
      value={{
        state,
        setSelectedServer,
        setSelectedGame,
        toggleAircraft,
        setUserRole,
        addInstructor,
        removeInstructor,
        toggleInstructorStatus,
        bookSlot,
        cancelBooking,
        addTimeSlots,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
