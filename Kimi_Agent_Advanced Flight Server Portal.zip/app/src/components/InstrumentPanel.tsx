import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import gsap from 'gsap';

export default function InstrumentPanel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0a);
    scene.fog = new THREE.Fog(0x0a0a0a, 10, 50);

    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(2, 1, 6);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Mouse interaction
    let mouseX = 0;
    let mouseY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = (e.clientX - window.innerWidth / 2) * 0.0005;
      mouseY = (e.clientY - window.innerHeight / 2) * 0.0005;
    };
    document.addEventListener('mousemove', handleMouseMove);

    // Instrument group
    const instrumentGroup = new THREE.Group();
    scene.add(instrumentGroup);

    // Materials
    const casingMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.9,
      roughness: 0.2,
    });
    const bezelMaterial = new THREE.MeshStandardMaterial({
      color: 0x2a2a2a,
      metalness: 0.95,
      roughness: 0.1,
    });
    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0,
      roughness: 0,
      transmission: 0.95,
      thickness: 0.1,
      transparent: true,
      opacity: 0.3,
    });
    const faceMaterial = new THREE.MeshStandardMaterial({
      color: 0x050505,
      roughness: 0.8,
    });
    const tickMaterial = new THREE.MeshBasicMaterial({ color: 0xe0e0e0 });
    const drumMaterial = new THREE.MeshStandardMaterial({
      color: 0x0a0a0a,
      roughness: 0.5,
    });
    const needleMaterial = new THREE.MeshStandardMaterial({
      color: 0xff6b1a,
      metalness: 0.5,
      roughness: 0.3,
    });
    const hubMaterial = new THREE.MeshStandardMaterial({
      color: 0x2a2a2a,
      metalness: 0.9,
      roughness: 0.1,
    });
    const screwMaterial = new THREE.MeshStandardMaterial({
      color: 0x888888,
      metalness: 0.9,
      roughness: 0.2,
    });

    // 1. Outer Casing
    const casing = new THREE.Mesh(
      new THREE.CylinderGeometry(1.4, 1.4, 0.4, 64),
      casingMaterial
    );
    casing.rotation.x = Math.PI / 2;
    casing.castShadow = true;
    casing.receiveShadow = true;
    instrumentGroup.add(casing);

    // 2. Bezel Ring
    const bezel = new THREE.Mesh(
      new THREE.TorusGeometry(1.4, 0.08, 16, 100),
      bezelMaterial
    );
    instrumentGroup.add(bezel);

    // 3. Glass Cover
    const glass = new THREE.Mesh(
      new THREE.CircleGeometry(1.35, 64),
      glassMaterial
    );
    glass.position.z = 0.21;
    instrumentGroup.add(glass);

    // 4. Face Background
    const face = new THREE.Mesh(
      new THREE.CircleGeometry(1.3, 64),
      faceMaterial
    );
    face.position.z = 0.15;
    instrumentGroup.add(face);

    // 5. Tick Marks
    for (let tick = 0; tick < 360; tick += 5) {
      const angle = (tick * Math.PI) / 180;
      const isMajor = tick % 30 === 0;
      const length = isMajor ? 0.15 : 0.08;
      const width = isMajor ? 0.03 : 0.01;
      const tickMesh = new THREE.Mesh(
        new THREE.BoxGeometry(width, length, 0.01),
        tickMaterial
      );
      tickMesh.position.set(Math.cos(angle) * 1.1, Math.sin(angle) * 1.1, 0.16);
      tickMesh.rotation.z = angle;
      instrumentGroup.add(tickMesh);
    }

    // 6. Drum Counter Assembly (simplified without font)
    const drumGroup = new THREE.Group();
    drumGroup.position.set(0, -0.4, 0.18);
    instrumentGroup.add(drumGroup);

    const drums: { mesh: THREE.Mesh; update: (value: number) => void }[] = [];

    for (let d = 0; d < 3; d++) {
      const drumMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.2, 0.2, 0.1, 32),
        drumMaterial
      );
      drumMesh.rotation.x = Math.PI / 2;
      drumMesh.position.set((d - 1) * 0.55, 0, 0);
      drumGroup.add(drumMesh);

      drums.push({
        mesh: drumMesh,
        update: (value: number) => {
          const displayValue = Math.floor(value) % 10;
          drumMesh.rotation.x = Math.PI / 2 + (displayValue / 10) * Math.PI * 2;
        },
      });
    }

    // 7. Drum Background
    const drumBg = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.5, 0.02),
      new THREE.MeshStandardMaterial({ color: 0x1a1a1a, metalness: 0.8, roughness: 0.3 })
    );
    drumBg.position.set(0, -0.4, 0.17);
    instrumentGroup.add(drumBg);

    // 8. Needle
    const needleGroup = new THREE.Group();
    needleGroup.position.z = 0.18;

    const needleBody = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.9, 0.02),
      needleMaterial
    );
    needleBody.position.y = 0.3;
    needleGroup.add(needleBody);

    const needleTail = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.3, 0.02),
      needleMaterial
    );
    needleTail.position.y = -0.15;
    needleGroup.add(needleTail);

    const hub = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 16, 16),
      hubMaterial
    );
    needleGroup.add(hub);

    instrumentGroup.add(needleGroup);

    // 9. Hub Cap
    const hubCap = new THREE.Mesh(
      new THREE.SphereGeometry(0.06, 16, 16),
      new THREE.MeshStandardMaterial({ color: 0x1a1a1a, metalness: 0.9, roughness: 0.1 })
    );
    hubCap.position.z = 0.22;
    instrumentGroup.add(hubCap);

    // 10. Screws
    const screwPositions = [
      [0.9, 0.9], [-0.9, 0.9], [0.9, -0.9], [-0.9, -0.9],
    ];
    screwPositions.forEach(([x, y]) => {
      const screw = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, 0.02, 8),
        screwMaterial
      );
      screw.rotation.x = Math.PI / 2;
      screw.position.set(x, y, 0.22);
      instrumentGroup.add(screw);
    });

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1);
    mainLight.position.set(5, 5, 5);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 1024;
    mainLight.shadow.mapSize.height = 1024;
    scene.add(mainLight);

    const orangeLight = new THREE.PointLight(0xff6b1a, 2, 10);
    orangeLight.position.set(-2, 1, 3);
    scene.add(orangeLight);

    const blueLight = new THREE.PointLight(0x4488ff, 0.5, 10);
    blueLight.position.set(2, -1, 2);
    scene.add(blueLight);

    const backLight = new THREE.DirectionalLight(0x445566, 0.5);
    backLight.position.set(-3, 2, -2);
    scene.add(backLight);

    // Camera animation
    gsap.from(camera.position, {
      z: 10,
      y: 3,
      x: 4,
      duration: 2.5,
      ease: 'power3.out',
    });

    gsap.from(instrumentGroup.rotation, {
      y: Math.PI,
      z: 0.2,
      duration: 3,
      ease: 'power2.out',
      delay: 0.2,
    });

    // Animation loop
    let time = 0;
    let altitude = 0;
    let targetAltitude = 0;
    let animationId: number;

    const animate = () => {
      animationId = requestAnimationFrame(animate);
      time += 0.01;

      targetAltitude = 5000 + Math.sin(time * 0.5) * 3000 + Math.sin(time * 0.1) * 1000;
      altitude += (targetAltitude - altitude) * 0.02;

      const altitudeInThousands = Math.floor(altitude / 1000);
      const digit1 = Math.floor(altitudeInThousands / 100) % 10;
      const digit2 = Math.floor(altitudeInThousands / 10) % 10;
      const digit3 = altitudeInThousands % 10;

      if (drums[0]) drums[0].update(digit1);
      if (drums[1]) drums[1].update(digit2);
      if (drums[2]) drums[2].update(digit3);

      needleGroup.rotation.z = -(altitude / 1000) * ((Math.PI * 2) / 10);

      // Mouse tilt
      instrumentGroup.rotation.y += (mouseX - instrumentGroup.rotation.y) * 0.05;
      instrumentGroup.rotation.x += (mouseY - instrumentGroup.rotation.x) * 0.05;

      renderer.render(scene, camera);
    };

    animate();

    // Resize handler
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      document.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        position: 'absolute',
        inset: 0,
        zIndex: 0,
      }}
    />
  );
}
