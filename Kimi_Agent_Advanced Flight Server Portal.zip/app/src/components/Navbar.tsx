import { useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Plane, TowerControl, Menu, X, Shield } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { state, setUserRole } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const isHub = location.pathname === '/';

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 flex items-center px-6"
      style={{ background: 'rgba(10, 10, 10, 0.9)', backdropFilter: 'blur(12px)' }}>
      <div className="max-w-[1200px] mx-auto w-full flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 group"
        >
          <Plane className="w-5 h-5 text-[#ff6b1a] transition-transform group-hover:rotate-12" />
          <span className="text-white font-semibold text-lg tracking-[0.08em]">
            FLIGHT PLATFORM
          </span>
        </button>

        {/* Center nav links */}
        <div className="hidden md:flex items-center gap-8">
          <button
            onClick={() => navigate('/')}
            className={`text-sm font-medium transition-colors hover:text-[#ff6b1a] ${isHub ? 'text-[#ff6b1a]' : 'text-[#a0a0a0]'}`}
          >
            Home
          </button>
          <button
            onClick={() => navigate('/flightline')}
            className={`text-sm font-medium transition-colors hover:text-[#ff6b1a] flex items-center gap-1.5 ${location.pathname === '/flightline' ? 'text-[#ff6b1a]' : 'text-[#a0a0a0]'}`}
          >
            <Plane className="w-3.5 h-3.5" />
            The FlightLine
          </button>
          <button
            onClick={() => navigate('/tower8')}
            className={`text-sm font-medium transition-colors hover:text-[#ff6b1a] flex items-center gap-1.5 ${location.pathname === '/tower8' ? 'text-[#ff6b1a]' : 'text-[#a0a0a0]'}`}
          >
            <TowerControl className="w-3.5 h-3.5" />
            Tower8
          </button>
        </div>

        {/* Right side */}
        <div className="hidden md:flex items-center gap-4">
          {/* Role switcher */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className="flex items-center gap-2 text-sm text-[#a0a0a0] hover:text-[#ff6b1a] transition-colors"
            >
              <Shield className="w-4 h-4" />
              <span className="capitalize">{state.userRole}</span>
            </button>
            {roleMenuOpen && (
              <div className="absolute right-0 top-full mt-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg py-1 min-w-[140px] shadow-xl">
                {(['trainee', 'instructor', 'admin'] as const).map(role => (
                  <button
                    key={role}
                    onClick={() => { setUserRole(role); setRoleMenuOpen(false); }}
                    className={`w-full text-left px-4 py-2 text-sm capitalize transition-colors hover:bg-[#2a2a2a] ${state.userRole === role ? 'text-[#ff6b1a]' : 'text-[#a0a0a0]'}`}
                  >
                    {role}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button className="btn-bordered py-2 px-5 text-xs h-9">
            Discord Login
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="md:hidden text-white"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 top-16 bg-[#0a0a0a] z-40 md:hidden p-6">
          <div className="flex flex-col gap-6">
            <button
              onClick={() => { navigate('/'); setMobileOpen(false); }}
              className="text-left text-lg text-white"
            >
              Home
            </button>
            <button
              onClick={() => { navigate('/flightline'); setMobileOpen(false); }}
              className="text-left text-lg text-white flex items-center gap-2"
            >
              <Plane className="w-5 h-5 text-[#ff6b1a]" />
              The FlightLine
            </button>
            <button
              onClick={() => { navigate('/tower8'); setMobileOpen(false); }}
              className="text-left text-lg text-white flex items-center gap-2"
            >
              <TowerControl className="w-5 h-5 text-[#ff6b1a]" />
              Tower8
            </button>
            <div className="pt-4 border-t border-[#2a2a2a]">
              <p className="caption mb-3">Role</p>
              <div className="flex gap-2 flex-wrap">
                {(['trainee', 'instructor', 'admin'] as const).map(role => (
                  <button
                    key={role}
                    onClick={() => { setUserRole(role); }}
                    className={`px-4 py-2 rounded-lg text-sm capitalize border ${state.userRole === role ? 'border-[#ff6b1a] text-[#ff6b1a]' : 'border-[#2a2a2a] text-[#a0a0a0]'}`}
                  >
                    {role}
                  </button>
                ))}
              </div>
            </div>
            <button className="btn-bordered mt-4">Discord Login</button>
          </div>
        </div>
      )}
    </nav>
  );
}
